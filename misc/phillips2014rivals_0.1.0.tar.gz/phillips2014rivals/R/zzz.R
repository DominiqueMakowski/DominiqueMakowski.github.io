
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Documention for Phillips et al. (2014): 'Rivals in the Dark'")
  packageStartupMessage("phillips2014rivals.guide() opens the package guide.")
  packageStartupMessage("Email: Nathaniel.D.Phillips.is@gmail.com")

}
