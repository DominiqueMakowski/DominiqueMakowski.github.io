#' Solitary group data
#'
#' Solitary condition data at the game level
#'
#'
#' @format A data frame containing 720 rows and 58 columns.
#' \describe{
#'   \item{Index.Game}{string. The participant and game number.}
#'   \item{Sampling.Trials}{integer. The number of samples the participant took before making a decision.}
#'   \item{ChoiceHEV}{logical. Was the selected option the option with the higher EV?}
#'   \item{Choice}{integer. Which option did the player choose?}
#'   \item{Round}{integer. The round number. Ranges from 1 to 5.}
#'   \item{Urn.0}{numeric. Characteristics of urn 0.}
#'   \item{Urn.1}{numeric. Characteristics of urn 1.}
#'   \item{Experiment}{integer. The experiment number of the participant. This is just a sequential number indicating which group participants were in.}
#'   \item{Order}{string. The stimuli order for the given participant.}
#'   \item{Option.HEV}{binary. Which option was the high expected value option?}
#'   \item{Option.0.ProbNeg, Option.0.PropPos,...}{numeric. What was the proportion of negative / positive options for urn 0 / 1?}
#'   \item{Option.HM}{binary. Which option had the higher sample mean?}
#'   \item{Mean.Pop.Samp.Match}{binary. Did the option with the higher sample mean also have the higher population mean?}
#'   \item{Option.0.Allocation,Option.1.Allocation}{numeric. What percent of samples did the participant allocate to each option?}
#'   \item{H.p.pos,L.p.neg,Condition.A}{numeric. Depricated.}
#'   \item{OSF}{logical. Was the option one-sample favorable?}
#'  }
#' @examples
#'
#'
#'
#'  # Histogram of trials
#'
#'  hist(Sol.Game.df$Sampling.Trials)
#'
#'


"Sol.Game.df"
