#' Competitive trial data
#'
#' Competitive condition data at the trial level
#'
#'
#' @format A data frame containing 2043 rows and 43 columns.
#' \describe{
#'   \item{Game}{string. The gamb enumber}
#'   \item{Date,Time}{string. Date and time of action}
#'   \item{Round}{integer. The decision round. There were 5 rounds in total.}
#'   \item{Inspect.Option}{binary. Which option did the participant inspect? -99 means that the player did not inspect but made a decision.}
#'   \item{Inspect.Value}{numeric. The outcome of the inspection.}
#'   \item{Sampling.Decision}{numeric. Which option did the player inspect?}
#'  }
#' @details For additional details about column values, look at ?Sol.Trial.df
#'


"Comp.Trial.df"
