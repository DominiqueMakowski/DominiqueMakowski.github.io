## ---- echo = FALSE-------------------------------------------------------
load("../data/data_complete.RData")
source("../R/compsim_function.R")
knitr::opts_chunk$set(collapse = TRUE, fig.align='center')

## ------------------------------------------------------------------------
# Simulate the probability of obtaining a high EV option in the competitive sampling game.
sample.sim <- Competitive.Sampling.Simulation.fun(Max.N = 10,      # Maximum sample size is 10
                                                  Sim.n = 1e3,     # Simulate 10,000 gambles 
                                                  Print.N = FALSE) # Don't print status reports

## ------------------------------------------------------------------------
# Pring results for a solitary player
sample.sim$`Solitary Performance`

## ----fig.width = 7, fig.height = 5, fig.align = 'center'-----------------
# Plot the
plot(x = 1:10, 
     y = sample.sim$`Solitary Performance`, 
     type = "b", 
     ylim = c(.5, 1), 
     xlab = "Sample size", 
     ylab = "p(Choose high EV)", 
     main = "Solitary player performance",
     xaxt = "n")

axis(1, 1:10)

## ------------------------------------------------------------------------
Competition.pHEV <- sample.sim$`Competition Performance`

# First few rows of competition results
head(Competition.pHEV)

## ------------------------------------------------------------------------
subset(Competition.pHEV, Agent == 5 & Competitor == 6)

## ---- echo = TRUE, fig.width = 4.5, fig.height = 4.5, fig.align = 'center', fig.cap = "Probability of the agent obtaining the high EV option given its planned sample size and its competitor in the competitive sampling game."----

par(mar = c(4, 4, .2, .2), lwd = 1)

plot(1, xlim = c(.5, 10 + .5), ylim = c(.5, 10 + .5), 
     type = "n", xaxt = "n", yaxt = "n", xlab = "", ylab = "")

## Tick marks

axis(side = 1, at = 1:10, labels = F, lwd.ticks = .6, lwd = 0)
axis(side = 2, at = 1:10, labels = F, lwd.ticks = .6, lwd = 0)

## Axis labels

mtext(1:10, side = 1, at = 1:10, line = .6, cex = .8)
mtext(1:10, side = 2, at = 1:10, line = .6, cex = .8, las = 1)

## Axis names

mtext("Agent", side = 1, las = 0, line = 1.8, cex = 1)
mtext("Planned Sampling Size", side = 1, las = 0, line = 2.7, cex = .8)

mtext("Competitor", side = 2, las = 0, line = 2.7, cex = 1)
mtext("Planned Sampling Size", side = 2, las = 0, line = 1.8, cex = .8)

for (Comp.SS in 1:10) {
  for (Agent.SS in 1:10) {

    pHEV <- Competition.pHEV$pHEV[Competition.pHEV$Agent == Agent.SS & 
                                    Competition.pHEV$Competitor == Comp.SS]

    rect(Agent.SS - .5, Comp.SS - .5, Agent.SS + .5, Comp.SS + .5, 
         col = gray(pHEV), lwd = .5, border = NA)

    if(pHEV < .5) {Text.Col <- "white"}
    if(pHEV >= .5) {Text.Col <- "black"}

    Text.Display <- paste(".", round(pHEV, 2) * 100, sep = "")

    text(Agent.SS, Comp.SS, Text.Display, col = Text.Col, cex = .7)

  }
}

