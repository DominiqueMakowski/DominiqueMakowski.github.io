## ---- echo = FALSE-------------------------------------------------------
load("../data/data_complete.RData")

## ------------------------------------------------------------------------
# Summary statistics for sampling sizes

# Competitive Condition
summary(Comp.Game.df$Trials)

# Solitary Condition
summary(Sol.Game.df$Sampling.Trials)

## ---- fig.width = 8, fig.height = 6, fig.align = 'center'----------------
# Put data into one dataframe
sampling.data <- data.frame("condition" = c(rep("Solitary", times = nrow(Sol.Game.df)),
                                            rep("Competitive", times = nrow(Comp.Game.df))),
                   "trials" = c(Sol.Game.df$Sampling.Trials, Comp.Game.df$Trials), 
                   stringsAsFactors = FALSE)

# Create a pirateplot
yarrr::pirateplot(trials ~ condition, data = sampling.data, main = "Sampling size comparison between competitive and solitary sampling conditions", sortx = "s")       

## ------------------------------------------------------------------------
# Solitary players selected the high ev option on 71% of trials
mean(Sol.Game.df$ChoiceHEV)

# Competitive choosers selected the high EV option on 57% of trials
mean(Comp.Game.df$Obtain.HEV[Comp.Game.df$Chooser == TRUE])

# Competitive receivers selected the high EV option on 42% of trials
mean(Comp.Game.df$Obtain.HEV[Comp.Game.df$Chooser == FALSE])

## ---- fig.width = 6, fig.height = 6, fig.align = 'center'----------------
# Rearrange the data for the pirateplot
solitary.choices <- Sol.Game.df$ChoiceHEV
chooser.choices <- Comp.Game.df$Obtain.HEV[Comp.Game.df$Chooser == TRUE]
receiver.choices <- Comp.Game.df$Obtain.HEV[Comp.Game.df$Chooser == FALSE]

choice.data <- data.frame(group = c(rep("solitary", length(solitary.choices)),
                                    rep("chooser", length(chooser.choices)),
                                    rep("receiver", length(receiver.choices))),
                          "choice" = c(solitary.choices, chooser.choices, receiver.choices))

# Create the pirateplot
yarrr::pirateplot(choice ~ group, 
                  data = choice.data, 
                  sortx = "s", 
                  point.o = 0, main = "Choice Accuracy")

abline(h = .5)

