## ---- echo = FALSE, out.width = "75%", fig.align = 'center', fig.cap = "Diagram of the competitive sampling game."----
knitr::include_graphics("../inst/images/gamediagram.png")

## ---- eval = FALSE-------------------------------------------------------
#  # Install the phillips2014rivals package from GitHub
#  
#  install.packages("https://github.com/ndphillips/ndphillips.github.io/blob/master/misc/phillips2014rivals_0.1.0.tar.gz?raw=true",
#                   repos = NULL,
#                   type = "source")
#  
#  # Load the package
#  library(phillips2014rivals)

## ---- eval = FALSE-------------------------------------------------------
#  # Install necessary packages
#  install.packages(c('yarrr', 'BayesFactor''))

## ---- eval = FALSE-------------------------------------------------------
#  @article{phillips2014rivals,
#    title={Rivals in the dark: How competition influences search in decisions under uncertainty},
#    author={Phillips, Nathaniel D and Hertwig, Ralph and Kareev, Yaakov and Avrahami, Judith},
#    journal={Cognition},
#    volume={133},
#    number={1},
#    pages={104--119},
#    year={2014},
#    publisher={Elsevier}
#  }

